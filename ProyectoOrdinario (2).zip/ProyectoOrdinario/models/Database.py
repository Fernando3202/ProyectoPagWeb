# models/Database.py
from flask_sqlalchemy import SQLAlchemy

class Database:
    _instance = None

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            cls._instance = SQLAlchemy()
            print("🔄 SQLAlchemy (Singleton) instanciado")
        return cls._instance

