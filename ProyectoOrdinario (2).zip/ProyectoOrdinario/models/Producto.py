from models.Database import Database

db = Database.get_instance()

class Producto(db.Model):
    __tablename__ = 'producto'

    id_producto = db.Column(db.Integer, primary_key=True)
    descripcion = db.Column(db.Text, nullable=False)
    costo = db.Column(db.Numeric(10, 2), nullable=False)
    stock = db.Column(db.Enum('existencia', 'agotado'), default='existencia')
    imagen = db.Column(db.String(255), nullable=True)
